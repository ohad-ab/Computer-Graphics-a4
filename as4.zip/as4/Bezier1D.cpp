#include "Bezier1D.h"

Bezier1D::Bezier1D(int segNum, int res, int mode, int viewport)
{
	
	//mesh->Bind();
	this->mode = mode;
	isCopy = false;
	viewports = viewport;
	shaderID = 1;
	materialID = 0;
	this->resT = res;
	//float c = ((4 / 3) * (sqrt(2.f * 81.f) - 9)/-9);
	M = { -1,3,-3,1,
			3,-6,3,0,
			-3,3,0,0,
			1,0,0,0};
	M = glm::transpose(M);
	this->segments = { glm::transpose(glm::mat4{ -5, 0, 0, 0,
									-5, 1.65684, 0, 90,
									-3.65684, 3, 0, 180,
									-2,3,0,0}),
						 glm::transpose(glm::mat4{ -2, 3, 0, 0,
									-1, 3, 0, 0,
									1, 3, 0, 180,
									2,3,0,0}),
						glm::transpose(glm::mat4{ 2, 3, 0, 0,
									3.65684 , 3, 0, 0,
									5, 1.65684, 0, 90,
									5,0,0,0}) };

	mesh = new MeshConstructor(GetLine(), false);
}

IndexedModel Bezier1D::GetLine()
{
	IndexedModel model;

	//LineVertex axisVertices[] =
	//{
	//	LineVertex(glm::vec3(1,0,0),glm::vec3(1,0,0)),
	//	LineVertex(glm::vec3(-1,0,0),glm::vec3(1,0,0)),
	//	LineVertex(glm::vec3(0,1,0),glm::vec3(0,1,0)),
	//	LineVertex(glm::vec3(0,-1,0),glm::vec3(0,1,0)),
	//	LineVertex(glm::vec3(0,0,1),glm::vec3(0,0,1)),
	//	LineVertex(glm::vec3(0,0,-1),glm::vec3(0,0,1)),
	//};


	//unsigned int axisIndices[] =
	//{
	//	0,1,
	//	2,3,
	//	4,5
	//};
	int ind = 0;
	for (int j = 0; j < segments.size(); j++)
	{
		for (unsigned int i = 0; i <= resT; i++)
		{
			glm::vec4 pos = GetPointOnCurve(j, i);
			model.positions.push_back(glm::vec3(pos.x, pos.y, 0));
			model.colors.push_back(glm::vec3(1, 0, 0));
			model.indices.push_back(ind);
			ind++;
		}
	}
		

	return model;
}

glm::vec4 Bezier1D::GetPointOnCurve(int segment, int t)
{
	float x = (float)t / (float)resT;
	glm::vec4 p(powf(x, 3), powf(x, 2), x, 1);

	glm::vec4 res = p * M*segments[segment];
	return res;
}

glm::vec4 Bezier1D::GetControlPoint(int segment, int indx) const
{
	if (segment >= 0 && segment < segments.size())
		return glm::vec4(segments[segment][0][indx], segments[segment][1][indx], 0, segments[segment][3][indx]);
	else if (segment == segments.size() && indx == 0)
		return glm::vec4(segments[segment-1][0][3], segments[segment-1][1][3], 0, segments[segment-1][3][3]);
	else
		return glm::vec4(0, 0, -1, 0);
}

void Bezier1D::CurveUpdate(int pointIndx, float dx, float dy, bool preserveC1)
{
	int seg = (pointIndx - 3) / segments.size();
	int p = (pointIndx - 3) % segments.size();
	if (seg == segments.size())
	{
		seg -= 1;
		p = 3;
	}
	MoveControlPoint(seg, p, dx, dy, preserveC1);
	mesh->ChangeLine(GetLine());
}

void Bezier1D::updateAngle(int pointIndx, float angle)
{
	int seg = (pointIndx - 3) / segments.size();
	int p = (pointIndx - 3) % segments.size();
	if(seg<GetSegmentsNum())
		segments[seg][3][p] = angle;
	else
		segments[seg-1][3][3] = angle;
}
void Bezier1D::MoveControlPoint(int segment, int indx, float dx, float dy, bool preserveC1)
{
	segments[segment][0][indx] += dx;
	segments[segment][1][indx] += dy;
	if (segment > 0 && segment < segments.size())
	{
		if (indx == 0) 
		{
			segments[segment - 1][0][3] += dx;
			segments[segment - 1][1][3] += dy;
			segments[segment - 1][0][2] += dx;
			segments[segment - 1][1][2] += dy;
			segments[segment][0][1] += dx;
			segments[segment][1][1] += dy;
		}
		if (indx == 3)
		{
			segments[segment][0][2] += dx;
			segments[segment][1][2] += dy;
		}
	}
	else if (segment == 0 && indx == 0)
	{
		segments[segment][0][1] += dx;
		segments[segment][1][1] += dy;
	}
	//else
	//{
	//	segments[segment - 1][0][2] += dx;
	//	segments[segment - 1][1][2] += dy;
	//}

}
int Bezier1D::CheckconvexHull(float x, float y)
{
	for (int i = 0; i < segments.size(); i++)
	{
		int maxX= segments[i][0][0];
		int minX= segments[i][0][0];
		for (int j = 1; j < 4; j++)
		{
			if (segments[i][0][j] > maxX)
				maxX = j;
		}
		for (int j = 1; j < 4; j++)
		{
			if (segments[i][0][j] < minX)
				minX = j;
		}
		if (maxX != minX)
		{
			float m = (segments[i][1][maxX] - segments[i][1][minX]) / (segments[i][0][maxX] - segments[i][0][minX]);
			float n = segments[i][1][maxX] - segments[i][0][maxX] *m;
			float d, maxd=0, w=-1, q=-1;
			for (int j = 0; j < 4; j++)
			{
				d = (m*segments[i][0][j] - segments[i][1][j] + n) / (sqrt(powf(m, 2) + 1));
				if (abs(d) > maxd)
				{
					maxd = d;
					if (w != -1)
						q = w;
					w = j;
				}
			}
			if (w != -1)
			{
				if (q != -1)
					;
			}

		}
	}
	return 1;
}

bool Bezier1D::CheckTriangle(int seg, int a, int b, int c, int d)
{
	//float m = (segments[seg][1][a] - segments[seg][1][b]) / (segments[seg][0][a] - segments[seg][0][b]);
	//float n = segments[seg][1][a] - segments[seg][0][a] * m;
	glm::vec2 A = { segments[seg][0][a],segments[seg][1][a] };
	glm::vec2 B = { segments[seg][0][b],segments[seg][1][b] };
	glm::vec2 C = { segments[seg][0][c],segments[seg][1][c] };
	
	if (A.x != B.x)
	{

	}
	return true;
}

Bezier1D::~Bezier1D(void) {

}